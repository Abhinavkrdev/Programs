/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

    double minmum(double b[])

{
   double min=b[0];
   int i;
   for(i=0;i<10;i++)
    if(min>b[i])
      min=b[i];
      
      return min;
}  


int main()
{
     double a[10],min;
   int i;
   printf("Enter number");
   for(i=0;i<10;i++)
   scanf("%lf",&a[i]);
   
   printf("Smallest number is %lf\n",minmum(a));
   
    return 0;
}