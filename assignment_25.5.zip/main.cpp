/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class ReverseNumber
{
    public:

    void printfun(int arr[],int size)
    {
        for(int i=0;i < size ; i++)
        cout << arr[i] << " ";
    }
int Reversefunc(int arr[],int start,int end)
 {
    while(start <end)
    {
      int temp= arr[start];
      arr[start] = arr[end];
      arr[end] = temp;
      start++;
      end--;
       
    }
 }
};

 int main()
{
    int arr[5]={1,2,3,4,5};
    int n= sizeof(arr) / sizeof(arr[0]);
    
    ReverseNumber obj;
    obj.printfun(arr,n);
    obj.Reversefunc(arr,0,n-1);
    cout<<endl<<"Reversed number is " ;
    obj.printfun(arr,n);
    
    return 0;
}