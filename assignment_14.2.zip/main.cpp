/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    double Avg,a[10],sum=0;;
   int i;
   printf("Enter numer");
   for(i=0;i<10;i++)
   {
   scanf("%lf",&a[i]);
   sum=sum+a[i];
   }
   printf("%lf\n",sum);
   Avg=sum/i;    
   
   
   printf("%lf",Avg);
   
    return 0;
}