/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,j,a[10],temp,n;
   printf("Enter 10 numbers\n");
   
   for(i=0;i<10;i++)
   scanf("%d",&a[i]);
   
   
   for(i=0;i<9;i++)
   {
       for(j=i+1;j<10;j++)
       {
           if(a[i]>a[j])
           {
           temp=a[i];
           a[i]=a[j];
           a[j]=temp;
           }
       }
   }
   
   for(i=0;i<10;i++)
   printf("%d",a[i]);

    return 0;
}
