/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int xtopowery(int x,int y)
{
    int num=1;
    while(x)
    {
        num=num*y;
        --x;
    }
    return num;
}



int main() {
    
    int x,y;
    cout << "Enter number x & y ";
    cin >> x >> y ;
    cout << "x to the power y is " << xtopowery(x,y ) ;
    return 0;
}

