/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>

using namespace std;

void print(vector<int> &V)
{
    for(int j=0;j< V.size();j++)
    {
        cout << V[j] << " ";
    }
     
}


int main()
{
    int n;
    cin >> n;
    int a;
     vector<int> V;
    
    for(int i=0;i<n;i++)
      {
          cin >>a;
          V.push_back(a);
          
          
      }     
   print(V);
   
   


    return 0;
}