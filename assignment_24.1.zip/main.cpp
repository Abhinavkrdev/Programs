/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;


    void checkprime(int num)

{
   int i;
   for(i=2;i<num;i++)
   {
   if(num%i==0)
   break;
   }
   if(num==i)
   cout << "Number is prime number" ;
   else
   cout << "Number is not prime" ;

}

int main()

{
    int num;
   cout << "Enter the number ";
   cin >> num;
   checkprime(num);
    return 0;
}