/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
      int N,i,a=-1,b=1,c,x;
    printf ("Enter the number");
        scanf("%d",&N);

        printf ("Enter the number you want to match");
            scanf("%d",&x);


    
    for(i=0;i<=N;i++)
    {
        c=a+b;

        
    if(c==x)
    {
        printf("Number is there in Fibonnaci Series");
    }
   
        a=b;
        b=c;

    }
    return 0;
}