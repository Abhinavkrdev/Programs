/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int HCF(int n1,int n2)
{
    int i, gcd;

   
    for(i=1; i <= n1 && i <= n2; ++i)
    {
      
        if(n1%i==0 && n2%i==0)
            gcd = i;
    }

    //printf("G.C.D of %d and %d is %d", n1, n2, gcd);
    return gcd;
}

int main()
{
    int n1, n2,s;
    printf("Enter two integers: ");
    scanf("%d %d", &n1, &n2);
    
    
    s=HCF(n1,n2);
        printf("G.C.D of %d and %d is %d", n1, n2, s);

}