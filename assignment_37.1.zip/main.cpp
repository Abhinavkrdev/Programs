/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
#include <stdio.h>

using namespace std;

/*void display(string x)
 {
   cout << V ;
 } */

int main()
{
    vector<string>V{"Abhinav","Kumar"};
     for (int i = 0; i < V.size(); i++)  

  {  

    cout << V[i] << " ";   

  }
    
    //cout << V[i];
    return 0;
}