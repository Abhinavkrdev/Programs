/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class circle
 {
 public :
 
 float Areaofcircl(float r)
 {
     return 3.14*r*r;
 }
};
int main()
{
   circle obj1;
   float Area;
   Area=obj1.Areaofcircl(2);
   cout << "Area of circle " << Area;
   return 0;
}