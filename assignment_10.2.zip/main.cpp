/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int SimpleInterest ()
  {
  
  double P,R,T,SI;
  printf("Enter Principal,Rate,Time : ");
  scanf("%lf",&P);
  scanf("%lf",&R);
  scanf("%lf",&T);



  SI=P*R*T / 100;
  
  printf("Area of circle is %lf",SI);
  
  }
 
  
int main()
{
   SimpleInterest();
        
    return 0;
}

