/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
       int a,i;
      printf("Enter number of N Even natural number to print ");
      scanf("%d",&a);
    for(i=1;i<=2*a;i++)
    if(i%2==0)
    printf("%d",i);

    return 0;
}