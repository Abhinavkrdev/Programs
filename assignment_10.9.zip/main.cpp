/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int checknum(int x)
{
    int y,z;
    printf("Enter the num you want to match");
     scanf("%d",&y);
     while(x!=0)
     {
        x%10==z;
         if(z==y)
           printf("Number matches");   
           else 
            printf("Number do not matches");   

        x/10==x;
     }
    
}
 

int main()
{
    int a;
    printf("Enter the num");
    scanf("%d",&a);
    checknum(a);   
    
    return 0;
}