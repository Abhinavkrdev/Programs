/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
   int a,b,c,choice;
   printf("Enter sides of Triangle");
   scanf("%d %d %d",&a,&b,&c);
  
  printf("Enter your choice");
  scanf("%d",&choice);
   switch(choice)
   {
       case 1 : if( a==b || b==c)
                printf("Isosceles Triangle"); 
                else 
                   printf("Not a Isosceles Triangle");
                   break;
       
       case 2 : if( a*a==b*b + c*c || b*b == a*a + c*c || c*c ==a*a + b*b)
                printf("Right Triangle");
                else 
                     printf("Not a Right Triangle"); 
                     break;
       
       case 3 : if ( a=b=c )
                printf ("Equilateral Triangle");  
                  else
                 printf("Not a Equilateral Triangle");
                  break;
       case 4 : exit;       
      default : printf("Invalid option");   
   }
   
   
    return 0;
}