/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int isEven(int x)
{
    if(x%2==0)
     
    return 1;

    else
    
    return 0;
}

/*int isOdd(int y)
{
   
    if(y%2!=0)
   
   return 0; 
} */

int main()
{
 int a;
 printf("Enter the number");
 scanf("%d",&a); 
 
 int s=isEven(a);
  
  if(s==1) 
     printf("number is Even");
     else 
          printf("number is Odd");

     
    return 0;
}