/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class Rect
 {
     float a,b;
 public :
 
 float AreaofRect(float a,float b)
 {
     return a*b;
 }
};
int main()
{
   Rect obj1;
   float Area;
   Area=obj1.AreaofRect(2,4);
   cout << "Area of circle " << Area;
   return 0;
}