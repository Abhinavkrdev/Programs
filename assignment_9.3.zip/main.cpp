/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
     int choice;
     printf("Enter Day number: ");
     scanf("%d",&choice);
     
     switch(choice)
     {
         case 1: printf("Warm Monday");break;
         case 2: printf("Cool Tuesday");break;
         case 3: printf("Sunny Wednesday");break;
         case 4: printf("Rainy Thrusday");break;
         case 5: printf("Fluffy Friday");break;
         case 6: printf("Quite Saturday ");break;
         case 7: printf("Happy Sunday");break;
         
          default: printf("Incorrect month");
         
    }
     
     
    return 0;
}