/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

template <class T>
T sum(T a[],int length)
{
 T ret=a[0];
 for(int i=0;i<length;i++)
  ret +=a[i];
  
  return ret;
} 
int main()
   {
       int int_data[5];
       float float_data[5];
       int i;
       
       printf("Enter 5 number");
       for(i=0;i<5;i++)
       scanf("%d",&int_data[i]);
       printf("%d",sum(int_data,5));
       
       printf("Enter 5 number");
       for(i=0;i<5;i++)
       scanf("%f",&float_data[i]);
       printf("%f",sum(float_data,5));
   }