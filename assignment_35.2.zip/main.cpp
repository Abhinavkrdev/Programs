/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

template <class T>
T Max(T x,T y)
    {
       if (x>y)
       {
        return x;
       }
       else
       {
        return y;
       }
       
    }

int main()
{
    //template <class M>
    float a,b;
    printf("Enter the num");
    scanf("%f %f",&a,&b);
    printf("%f",Max<float>(a,b));
    return 0;
}

