/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

template <class T>
T Max(T x,T y,T z)
    {
       if (x>y && x>z)
       {
        return x;
       }
       else if (y>z)
       {
        return y;
       }
        else 
        {
         return z;
        }
    }

int main()
{
    //template <class M>
    float a,b,c;
    printf("Enter the num");
    scanf("%f %f %f",&a,&b,&c);
    printf("%f",Max<float>(a,b,c));
    return 0;
}