/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
 class sqr
 {
  private:
  int a;
  //int b=0;
  public :
  int b=0;
  int square(int a)
  {
    b++;
    
    return a*a;
  } 
 };

 int main()
 {
   sqr obj;
   float num;
   num=obj.square(2);
   std::cout << "Square of num is " <<num<< std::endl;
   num=obj.square(3);
   std::cout << "Square of num is " <<num<< std::endl;
   cout << "Number of times function called "<< obj.b;
    return 0;
 }