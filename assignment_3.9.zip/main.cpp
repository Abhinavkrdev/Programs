/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int a,b,c;
  printf("Enter 3 Numbers");
 scanf("%d%d%d",&a,&b,&c);
 printf("%d%d%d\n",a,b,c);
 
 if(a>b && a>c)
   printf("a is greatest number");
      
   else if (b>c)
      printf("b is greatest number");
        
      else
           printf("c is greatest number");
            
           
           
           
      
    return 0;
}
