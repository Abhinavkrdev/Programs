/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int i,a[10],sum1=0,sum2=0;
   
   printf("Enter numer");
   for(i=0;i<10;i++)
   {
   scanf("%d",&a[i]);
   
   if(a[i]%2==0)
   sum1=sum1+a[i];
   else
   sum2=sum2+a[i];
   }
   printf("Sum of even number is %d \n",sum1);
   printf("Sum of odd number is %d \n",sum2);
   
   return 0;

}