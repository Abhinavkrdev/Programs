/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int a,b;
    cout << "Enter two number " ;
    cin >> a;
    cin >> b;
    if(a>b)
     cout << "Maxm number is "<< a; 
     else if (b>a)
        cout << "Maxm number is "<< b;
        else 
          cout << "Numbers are equal ";
    return 0;
}