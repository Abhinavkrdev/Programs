/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int choice;
     printf("Enter month number: ");
     scanf("%d",&choice);
     
     switch(choice)
     {
         case 1: printf("No. of = 31");break;
         case 2: printf("No. of = 28");break;
         case 3: printf("No. of = 31");break;
         case 4: printf("No. of = 30");break;
         case 5: printf("No. of = 31");break;
         case 6: printf("No. of = 30");break;
         case 7: printf("No. of = 31");break;
         case 8: printf("No. of = 31");break;
         case 9: printf("No. of = 30");break;
         case 10: printf("No. of = 31");break;
         case 11: printf("No. of = 30");break;
         case 12: printf("No. of = 31");break;
          default: printf("Incorrect month");
         
    }
     
     
     
    return 0;
}
