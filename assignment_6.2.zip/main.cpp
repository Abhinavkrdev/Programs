/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
       int a,i,sum=0;
      printf("Enter the number ");
      scanf("%d",&a);
    for(i=1;i<=2*a;i++)
    if(i%2==0)
       sum=sum+i;
    
    printf("Sum of first %d even natural number %d",a,sum);
    
    return 0;
}
