/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
    
int main()
{
    int a;
    printf("Enter the num to be round off");
    scanf("%d",&a);
    
    switch(a%2==0)
    {
    case 1: printf("Round off to the nearest odd num");
            a=a+1;
            printf("nearestnum is %d",a); break;
    case 0: printf("Invalid num");  break;
    
    default:  printf("Invalid num"); break;
    }
    return 0;
}