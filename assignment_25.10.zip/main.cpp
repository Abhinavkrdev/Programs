/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <iostream>
#include <bits/stdc++.h>

using namespace std;

class Area
{
  private:
   int l;
   int b;
   int r;
   
  public:
  float Areaofrect(float l,float b)
  {
      return l*b;
  }
  float AreaofSqr(float a)
  {
      return a*a;
  }
  float Areaofcircl(float r)
  {
      return 3.14*r*r;
  }
  void print()
  {
      cout <<"Area is"  << endl;
  }
};
  
 int main()
 {
     Area obj1,obj2,obj3;
     //obj1.Areaofrect(3,4);
     cout << "Area of rect" << obj1.Areaofrect(3,4) <<endl ;
     cout <<"Area of Sqr" << obj2.AreaofSqr(2) << endl;
     cout << "Area of circle"<<obj3.Areaofcircl(1);
     
 

    return 0;
}
