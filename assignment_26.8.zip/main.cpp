/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class Bank
{
  int principal;
  int rate;
  int year;
  public:
  Bank()
  {
    principal=100;
    rate=2;
    year=2;
  }
    int smplinterest()
    {
        return principal*rate*year/100;
    }
  int Display(int num)
  {
  cout<< "Simple interest "<< num;
  } 
    
};

int main()
{
    Bank b1;
    Bank();
    int num=b1.smplinterest();
    b1.Display(num);
    
    return 0;
}