/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <algorithm>
#include <iostream>

using namespace std;

int main()
{
   int arr[5]={2,9,1,7,0};
   int size=sizeof(arr)/sizeof(int);
   sort(arr,arr+5);
   cout <<"sorted Elements are :";
   for(int i=0;i<size;i++)
    cout <<arr[i]<< " ";   
    return 0;
}