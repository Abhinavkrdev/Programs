/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int fact(int x)
{
int i,fact=1,b;
   b=x;
   
   for(i=x;i>=1;i--)
   {
   fact= fact*x;
   x--;
   }
   return fact;
   //printf("Factorial of %d is %d",b,fact);
}
   



int main()
{
 int a,fact1;
   printf("Enter the number");
    scanf("%d",&a);
    
    fact1=fact(a);
    printf("Factorial of %d is %d",a,fact1);
    return 0;
}