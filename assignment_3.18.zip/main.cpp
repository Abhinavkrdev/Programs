/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;


 
void printNumberOfDays(int N)
{

	switch (N) {
	// Cases for 31 Days
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		printf("31 Days.");
		break;

	// Cases for 30 Days
	case 4:
	case 6:
	case 9:
	case 11:
		printf("30 Days.");
		break;

	// Case for 28/29 Days
	case 2:
		printf("28/29 Days.");
		break;

	default:
		printf("Invalid Month.");
		break;
	}
}

// Driver Code
int main()
{
	// Input Month
	int N = 4;

	// Function Call
	printNumberOfDays(N);

	return 0;
}

   
   