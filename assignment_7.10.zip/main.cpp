/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;



int main()
{
    int num, count = 1, rem, sum; 
    printf("0 is a Armstrong number\n");
           // printf("1 is a Armstrong number\n");
  
    while(count <= 1000)  
    {  
        num = count;  
        sum = 0;  
  
        while(num)  
        {  
            rem = num % 10;  
            sum = sum + (rem * rem * rem);  
            num = num / 10;  
        }  
  
        if(count == sum)  
        {  


            printf("%d is a Armstrong number\n", count);  
        }  
  
        count++;  
    }  
  

    return 0;
}