/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class Date 
{
    int dd,mm,yyyy;
    public:
    Date()
    {
         dd=1;
         mm=1;
         yyyy=2022;
    }
    
    int Displaydate()
    {
        cout <<"Date is "<< dd <<mm <<yyyy ;
    }
};

int main()
{
    Date d1;
    int num=d1.Displaydate();
    cout << num;

    return 0;
}
