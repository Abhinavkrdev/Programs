/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class box
{
  int len;
  int breath;
  int height;
  public:
  box()
  {
      len=1;
      breath=2;
      height=3;
  }
 int Volume()
 {
    return len*breath*height;
 }
    
};

 int main()
 {
  box b1;
  box();
  int Vol=b1.Volume();
  std::cout << "Volume of box is " << Vol  << std::endl;

    return 0;
 }