/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

template <class T>
T Max(T &x,T &y)
    {  
       y= x+y;
       x= y-x;
       y= y-x;
      
      return 0;
    }

int main()
{
    //template <class M>
    float a,b,c;
    printf("Enter the num");
    scanf("%f %f",&a,&b);
    Max(a,b);
    printf("%f %f",a,b);
    return 0;
}