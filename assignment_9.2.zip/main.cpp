/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
     double c,a,b;
     int choice;
     printf("\n1. Addition");
     printf("\n2. Substraction");
     printf("\n3. Multipication");
     printf("\n4. Division");
     printf("\n5. Exit");
     
     printf("\nEnter your choice ");
     scanf("%d",&choice);
     switch(choice)
      {
          case 1: printf("Enter two number "); 
                  scanf("%lf %lf",&a,&b);
                  c=a+b;
                  printf("%lf",c);     break;
          
          case 2: printf("Enter two number ");  
                  scanf("%lf %lf",&a,&b);
                  c=a-b;
                  printf("%lf",c);    break;
          
          case 3: printf("Enter two number ");  
                  scanf("%lf %lf",&a,&b);
                  c=a*b;
                  printf("%lf",c);     break;
          
          case 4: printf("Enter two number ");
                  scanf("%lf %lf",&a,&b);
                  c=a/b;
                  printf("%lf",c);   break;
                  
          case 5: printf("Exit"); break;    
          
          default : printf("Invalid option");
          
      }
     
     
    return 0;
}