/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
   int a,b,c,d,e;
   printf("Enter 5 sub marks out of 100\n");
      scanf(" %d %d %d %d %d",&a,&b,&c,&d,&e);
      
      if(a&&b&&c&&d&&e >= 33)
      
         printf("Student is passed");
         else
         printf("Student is fail");
         
      
      
    return 0;
}