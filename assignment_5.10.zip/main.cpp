/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
        int a,table=0,i;
   printf("Enter the number N for which yo want to print Table ");
   scanf("%d",&a);
   
   for(i=1;i<=10;i++)
   {
   table=a*i;
   
   printf("%d X %d = %d\n",a,i,table);
   }
    return 0;
    return 0;
}