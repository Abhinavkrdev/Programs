/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int a;
    double num;
    printf("Select 1.For negative to positive\n");
    printf("Select 2.For positive to negative\n");
        
    scanf("%d",&a);
    switch(a)
    {
        case 1: printf("Enter a negative num");
          scanf("%lf",&num);
        num = num*-1;
        printf("The positive form of num is %lf ",num);  break;
    
       case 2: printf("Enter a positive num");
          scanf("%lf",&num);
          num = num * -1;
        printf("The negative form of num is num %lf ",num);\
        default: printf("Invalid input or character Entered");  break;
}
    return 0;
}