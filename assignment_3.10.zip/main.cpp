/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    double sp,cp;
    double pp,lp;
    printf("Enter CP and SP\n");
    scanf("%lf %lf",&cp,&sp);
    
    pp=(sp-cp)/cp *100;
    lp=(cp-sp)/cp *100;
    
    if(sp-cp>0)
    printf("Profit Percentage is %lf",pp);
    else
    printf("Loss Percentage is %lf",lp);
    

    return 0;
}