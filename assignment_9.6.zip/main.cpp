/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
   int year, remainder;

   printf("Enter Year: ");
   scanf("%d",&year);

   remainder=((year%4==0)&&((year%400==0)||(year%100!=0)));

   switch(remainder)
   {

   case 1:
     printf("Leap Year");
     break;

   case 0:
     printf("Not Leap Year");
     break;

   default:
     printf("Invalid");
     break;

   }

   return 0;
}
    