/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[10]={2,6,7,9,3,4,8,1,11,0};
    int i,largest=0,s_largest=0;
     largest = a[0];
    
    for(i=1;i<=9;i++)
    {
    
      if(a[i]>largest)
     {
      s_largest=largest;
      largest=a[i];
     }
   
      if(a[i]>s_largest && a[i]<largest)
      {
      s_largest=a[i];
      }
    }
    
    printf("Largest number in array is %d \n",largest);
    printf("Second largest number in array is %d ",s_largest);
    
    return 0;
}

