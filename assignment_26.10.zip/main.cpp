/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

static int var=0;
class StaticCount
{
  public:
  
  int increment()
  {
  var++;
  }
  void Display()
  {
  std::cout << "var = " << var << std::endl;
  }
};

int main()
{
    StaticCount b1;
    b1.increment();
    b1.increment();
    b1.increment();
    b1.Display();

    return 0;
}